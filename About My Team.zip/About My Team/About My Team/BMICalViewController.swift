//
//  BMICalViewController.swift
//  About My Team
//
//  Created by STDCx on 5/8/24.
//

import UIKit

class BMICalViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var heightTextField: UITextField!
    @IBOutlet var weightTextField: UITextField!
    @IBOutlet var bmiValueLabel: UILabel!
    @IBOutlet var classLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        heightTextField.delegate = self // add this line
        weightTextField.delegate = self // add this line
        heightTextField.text = ""
        weightTextField.text = ""
        bmiValueLabel.text = "BMI Calculator"
        classLabel.text = "Enter height and weight"
    }
    // add this function
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func calculateBMI(_ sender: UIButton) {
        guard let heightTextFieldText = heightTextField.text, let weightTextFieldText = weightTextField.text else {
            return
        }
        let heightInMString = heightTextFieldText
        let weightInKgString = weightTextFieldText
        var bmiResultString = ""
        var classString = ""
        if let heightInM = Double(heightInMString), let weightInKg = Double(weightInKgString), heightInM > 0, weightInKg > 0 {
            let bmiResult = weightInKg / (heightInM * heightInM)
            classString = getBMIClassificationString(bmiResult)
            bmiResultString = String((bmiResult * 10).rounded() / 10)
        } else {
            bmiResultString = "Error"
            classString = "Error"
        }
        bmiValueLabel.text = bmiResultString
        classLabel.text = classString
    }

}

func getBMIClassificationString(_ bmiResult: Double) -> String {
    var classString = ""
    switch bmiResult {
    case let bmiResult where bmiResult < 18.4:
        classString = "Underweight"
    case let bmiResult where bmiResult < 24.49:
        classString = "Normal"
    case let bmiResult where bmiResult < 39.9:
        classString = "Overweight"
    case let bmiResult where bmiResult > 40.0:
        classString = "Obese"
    default:
        classString = "Error"
    }
    return classString
}
