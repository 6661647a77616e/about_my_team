//
//  MapViewController.swift
//  About My Team
//
//  Created by STDCx on 6/8/24.
//

import UIKit
import MapKit

class MapViewController: UIViewController {
    
    @IBOutlet var map: MKMapView!

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func unwindNewLocation(segue: UIStoryboardSegue) {
        if let sourceViewController = segue.source as? EnterCoordViewController, let newCoordinate = sourceViewController.newCoordinate {
            map.setRegion(MKCoordinateRegion(center: newCoordinate, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)), animated: true)
        }
    }

    
}
