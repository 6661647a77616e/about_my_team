//
//  ViewController.swift
//  About My Team
//
//  Created by STDCx on 3/8/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var myImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        myImageView.clipToCircle()
    }
}

extension UIImageView {
    func clipToCircle() {
        self.layoutIfNeeded()
        self.layer.borderColor = UIColor.systemYellow.cgColor
        self.layer.borderWidth = 10.0
        self.layer.cornerRadius = self.frame.height / 2
        self.clipsToBounds = true
    }
}
